<?php 
    interface sale{
        public function getSaleAmount();
        public function getItem();
        public function getPrice();
        public function getQuantity();
    }
?>